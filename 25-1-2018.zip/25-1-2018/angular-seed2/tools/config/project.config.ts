import { join } from 'path';

import { SeedConfig } from './seed.config';
import { ExtendPackages } from './seed.config.interfaces';

/**
 * This class extends the basic seed configuration, allowing for project specific overrides. A few examples can be found
 * below.
 */
export class ProjectConfig extends SeedConfig {

  PROJECT_TASKS_DIR = join(process.cwd(), this.TOOLS_DIR, 'tasks', 'project');

  constructor() {
    super();
    // this.APP_TITLE = 'Put name of your app here';
    // this.GOOGLE_ANALYTICS_ID = 'Your site's ID';

    /* Enable typeless compiler runs (faster) between typed compiler runs. */
    // this.TYPED_COMPILE_INTERVAL = 5;
this.NPM_DEPENDENCIES = [
      ...this.NPM_DEPENDENCIES,
      /* Select a pre-built Material theme */
      { src: '../../node_modules/primeng/resources/themes/omega/theme.css', inject: true },
      { src: '../../node_modules/primeng/resources/primeng.min.css', inject: true },
      { src: '../../node_modules/font-awesome/css/font-awesome.min.css', inject: true }      
    ];
    interface InjectableDependency {
      src: string;
      inject: string | boolean;
    }

    // Add `NPM` third-party libraries to be injected/bundled.
    this.NPM_DEPENDENCIES = [
      ...this.NPM_DEPENDENCIES,
      // {src: 'jquery/dist/jquery.min.js', inject: 'libs'},
      // {src: '../../node_modules/moment/moment.js', inject: 'libs'},       
     //  {src: '../../node_modules/lodash/lodash.js', inject: 'libs'},  
     //  {src: '../../node_modules/ng2-carouselamos/dist/ng2-carouselamos.module.js', inject: 'libs'},     
    ];

    // Add `local` third-party libraries to be injected/bundled.
    this.APP_ASSETS = [
      // {src: `${this.APP_SRC}/your-path-to-lib/libs/jquery-ui.js`, inject: true, vendor: false}
      // {src: `${this.CSS_SRC}/path-to-lib/test-lib.css`, inject: true, vendor: false},
    ];

    this.ROLLUP_NAMED_EXPORTS = [
      ...this.ROLLUP_NAMED_EXPORTS,
      //{'node_modules/immutable/dist/immutable.js': [ 'Map' ]},
    ];

let additionalPackages: ExtendPackages[] = [{
     name: 'moment',
     // Path to the package's bundle
     path: 'node_modules/moment/moment.js'
   }];
this.addPackagesBundles(additionalPackages);

let additionalPackages1: ExtendPackages[] = [{
     name: 'lodash',
     // Path to the package's bundle
     path: 'node_modules/lodash/lodash.js'
   }];
    this.addPackagesBundles(additionalPackages1);

let additionalPackages2: ExtendPackages[] = [{
     name: 'ng2-carouselamos',
     // Path to the package's bundle
     path: 'node_modules/ng2-carouselamos/dist/ng2-carouselamos.module.js'
   }];
    this.addPackagesBundles(additionalPackages2);

  //   let additionalPackages3: ExtendPackages[] = [{
  //    name: 'localstorage',
  //    // Path to the package's bundle
  //    path: 'node_modules/angular-localstorage/index.js'
  //  }];
  //   this.addPackagesBundles(additionalPackages3);

    // Add packages (e.g. ng2-translate)
    // let additionalPackages: ExtendPackages[] = [{
    //   name: 'ng2-translate',
    //   // Path to the package's bundle
    //   path: 'node_modules/ng2-translate/bundles/ng2-translate.umd.js'
    // }];
    //
    // this.addPackagesBundles(additionalPackages);

    /* Add proxy middleware */
    // this.PROXY_MIDDLEWARE = [
    //   require('http-proxy-middleware')('/api', { ws: false, target: 'http://localhost:3003' })
    // ];

    /* Add to or override NPM module configurations: */
    // this.PLUGIN_CONFIGS['browser-sync'] = { ghostMode: false };
  }

}
