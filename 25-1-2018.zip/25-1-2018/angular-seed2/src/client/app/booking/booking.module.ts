import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { BookingComponent } from './booking.component';
import { BookingRoutingModule } from './booking-routing.module';

@NgModule({
  imports: [CommonModule, BookingRoutingModule],
  declarations: [BookingComponent],
  exports: [BookingComponent]
})
export class BookingModule { }