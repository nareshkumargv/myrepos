import { Component, Input,Output, EventEmitter } from '@angular/core';

import { estimate } from '../home/estimates';
import { EstimateService } from '../home/estimate.service';

@Component({
  moduleId: module.id,
  selector: 'sd-login',
  templateUrl: 'login.component.html'
})
export class LoginComponent {
 selectedCustomer: estimate;
  @Input() customers: estimate[];

  message: string = "1500"
  @Output() messageEvent = new EventEmitter<string>();

  constructor() { }

    sendMessage() {
    this.messageEvent.emit(this.message)
  }

  ngOnInit(): void { }

}