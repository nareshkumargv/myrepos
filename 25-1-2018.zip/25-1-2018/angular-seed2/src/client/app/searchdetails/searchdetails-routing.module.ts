import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SearchDetailsComponent } from './searchdetails.component';

@NgModule({
  imports: [
    RouterModule.forChild([
      { path: 'searchdetails/:sid/:mid/:lid', component: SearchDetailsComponent }
    ])
  ],
  exports: [RouterModule]
})
export class SearchDetailsRoutingModule { }