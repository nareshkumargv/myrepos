export class clients {
      id: number;      
      cname: string  
}