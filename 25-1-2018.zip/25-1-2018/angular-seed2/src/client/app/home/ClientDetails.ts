export class ClientDetails{
    clientInfo: any;
    clientServicesInfo: any[];

    // constructor(){
    //     // this.clientInfo = {};
    //     // this.clientServicesInfo = [];
    // }
}