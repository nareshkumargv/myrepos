import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { schedule } from './schedule';

@Injectable()
export class ScheduleService {

    constructor(private http: Http) { }

    getSchedule(): Observable<schedule[]> {
        return this.http.get('../app/home/schedule.json')
            .map((res: Response) => res.json());            
    }    

}