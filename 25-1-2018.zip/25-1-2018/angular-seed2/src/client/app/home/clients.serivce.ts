import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { clients } from './clients';

@Injectable()
export class ClientsService {

    constructor(private http: Http) { }

    getClients(): Observable<clients[]> {
        return this.http.get('../app/home/clients.json')
            .map((res: Response) => res.json());            
    }    

}