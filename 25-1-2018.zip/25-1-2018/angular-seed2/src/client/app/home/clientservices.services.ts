import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { clientServices } from './clientservices';

@Injectable()
export class ClientSerServices {

    constructor(private http: Http) { }

    getClientservices(): Observable<clientServices[]> {
        return this.http.get('../app/home/clientservices.json')
            .map((res: Response) => res.json());            
    }    

}