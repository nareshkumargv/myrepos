import { Pipe, PipeTransform } from '@angular/core';

import {clients} from './clients';
import {clientServices} from './clientservices';

@Pipe({
    name: 'myfilter',
    pure: false
})
export class ClientFilterPipe implements PipeTransform {

transform(items:clients[],filter:clientServices):any {
    if (!items || filter) {
        return items;
    }
    console.log(items);
    console.log(filter);
   
}


}


