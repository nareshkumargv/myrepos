import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { estimate } from './estimates';

@Injectable()
export class EstimateService {

    constructor(private http: Http) { }

    getEstimate(): Observable<estimate[]> {
        return this.http.get('../app/home/estimate.json')
            .map((res: Response) => res.json());            
    }    

}