export class estimate {
    constructor(public id: number, public amount: number) { }
}