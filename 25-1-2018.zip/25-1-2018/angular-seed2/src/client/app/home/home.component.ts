import { Component, OnInit, EventEmitter, Input, Output, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

import { Observable } from 'rxjs/Rx';

import { DatePipe } from '@angular/common';
// import { NameListService } from '../shared/name-list/name-list.service';


import { FilterService } from './filterservice';
import { Service } from './services';
import { Model } from './models';
import { Location } from './locations';

import { Data } from './data';
import { DataService } from './dataservice';

import { schedule } from './schedule';
import { ScheduleService } from './schedule.service';

import { estimate } from './estimates';
import { EstimateService } from './estimate.service';

import { clients } from './clients';
import { ClientsService } from './clients.serivce';

import { clientServices } from './clientservices';
import { ClientSerServices } from './clientservices.services';

import { ClientDetails } from './ClientDetails';

/**
 * This class represents the lazy loaded HomeComponent.
 */



@Component({
  moduleId: module.id,
  selector: 'sd-home',
  templateUrl: 'home.component.html',
  styleUrls: ['home.component.css'],

  providers: [FilterService, ScheduleService, EstimateService, ClientsService, ClientSerServices]
})
export class HomeComponent implements OnInit {
selected : boolean;

  showSelectedList(item:any) {
    console.log(item);
    this.selected = !this.selected;
  }


  @Input() estimates: estimate[];
  @Input() selectedestimate: estimate;
  @Output() selectedChange: EventEmitter<estimate> = new EventEmitter();
 
  objClientDetails: any[] = [];// = new ClientDetails();

  //clientInfo:any;
  //clientServicesInfo:any;
  message: string;

  receiveMessage($event: any) {
    this.message = $event
  }

  showSelected: boolean;
  wd: any;
  ts: any;
  wd1: any;
  ts1: any;


  currentDate: Date;
  /***Model Popup***/
  selectedser: any;

  display: boolean = false;
  showDialog() {
    this.display = true;
  }
  /***Model Popup***/

  date5: Date = new Date();
  // today = Date();
  myDate: Date = new Date();

  //public myDate: any;
  Schedules: any[];
  Estimate: any[];
  schcount: any;

  clients: any[];
  clientser: any[];

  sysdate: any;
  selectedsysdate: any;
  dates: Date[];

  rangeDates: Date[];
  minDate: Date;
  maxDate: Date;
  es: any;
  invalidDates: Array<Date>

  @Output() change = new EventEmitter();
  @Output() focus = new EventEmitter();

  formatDate(dateObject: Date, includeTime: boolean = false) {
    if (!dateObject)
      return '';

    let time: string = '';
    let newDate = new Date(dateObject);
    if (includeTime) {
      // fix for IE
      let noon: string = 'am';
      let h: number = newDate.getHours();
      if (h >= 12) {
        noon = 'pm';
        h = h - 12;
      }
      if (h === 0)
        h = 12;
      let m: number = newDate.getMinutes();
      let mm: string = (m < 10) ? ('0' + m) : ('' + m);
      let hh: string = (h < 10) ? ('0' + h) : ('' + h);
      time = ' | ' + hh + ':' + mm + ' ' + noon;
    }
    let pipe = new DatePipe('en-US');

    // return pipe.transform(dateObject, 'MM/dd/yyyy | hh:mm');
    //return pipe.transform(newDate, 'MM/dd/yyyy') + time;
    return pipe.transform(newDate, 'MM/dd/yyyy');
  }


  onSelectDate(event: any) {
    this.change.emit(event);

    // console.log(event);
    let d = new Date(Date.parse(event));
    //this.myDate = event;

    this.myDate = this.formatDate(event, false);
    // console.log(this.myDate);

    //  this.ScheduleService.getSchedule().subscribe(res => this.Schedules = res);

    // if(this.Schedules !== undefined) {
    // this.schcount = this.Schedules.filter((selectedDate) => selectedDate.day == this.myDate);
    // }
    //console.log(this.schcount);

    this.ScheduleService.getSchedule().subscribe(res => {
      this.Schedules = res;
      this.Schedules = this.Schedules.filter((selectedDate) => selectedDate.day === this.myDate)
    });

  }

  onFocus() {
    this.focus.emit();
  }

  onSelectionChange(ser) {
    let selectedser = Object.assign({}, this.selectedser, ser);
    this.wd = selectedser.day;
    this.ts = selectedser.timeslot;
  }


  selectedService: Service = new Service(0, 'Service1');
  services: Service[];

  selectedModel: Service = new Model(0, 1, 'Model 1');
  models: Model[];

  selectedLocation: Service = new Location(0, 1, 1, 'Loc 1');
  locations: Location[];

  sData: Data[];
  fdata: Data[];

  test: any = 'testing';
  //disabled = true;

  constructor(private router: Router, public _filterservice: FilterService, private DataService: DataService, private ScheduleService: ScheduleService,
    private estimateService: EstimateService,
    private clientsService: ClientsService,
    private clientSerServices: ClientSerServices) {
    //this.date5.setMonth(this.date5.getMonth());    

    this.services = this._filterservice.getServices();
    this.showSelected = false;
  }

  onSelect(serviceid: any) {
    //this.disabled = !this.disabled;
    this.models = this._filterservice.getModels().filter((item) => item.serviceid == serviceid);
  }

  onSelectmodel(modelid: any) {
    // this.disabled = !this.disabled;
    //console.log(modelid);    
    this.locations = this._filterservice.getLocations().filter((item) => item.modelid == modelid);
  }

  ngOnInit() {
/*****/
    Observable.forkJoin([this.clientsService.getClients(), this.clientSerServices.getClientservices()])
      .subscribe((data: any[]) => {
        this.clients = data[0],
        this.clientser = data[1];

        this.clients.forEach((client: any) => {
          var obj:ClientDetails = new ClientDetails();
          obj.clientInfo = client;
          obj.clientServicesInfo = this.clientser.filter((ser: any) => ser.cid == client.id);
          this.objClientDetails.push(obj);
        });
      });
/*****/



    // this.clientsService.getClients().subscribe(res => {
    // this.clients = res;    
    // });

    // this.clientSerServices.getClientservices().subscribe(res => {
    // this.clientser = res;    
    // });




    this.es = {
      firstDayOfWeek: 0,
      dayNames: ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
      dayNamesShort: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"],
      dayNamesMin: ["Su", "Mo", "Tu", "We", "Th", "Fr", "Sa"],
      monthNames: ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"],
      monthNamesShort: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"],
      today: 'Today',
      clear: 'Clear'
    }

    // this.tr = {
    //     firstDayOfWeek : 1
    // }

    let today = new Date();
    let month = today.getMonth();
    let year = today.getFullYear();
    let prevMonth = (month === 0) ? 11 : month - 1;
    let prevYear = (prevMonth === 11) ? year - 1 : year;
    let nextMonth = (month === 11) ? 0 : month + 1;
    let nextYear = (nextMonth === 0) ? year + 1 : year;
    this.minDate = new Date();
    this.minDate.setMonth(prevMonth);
    this.minDate.setFullYear(prevYear);
    this.maxDate = new Date();
    this.maxDate.setMonth(nextMonth);
    this.maxDate.setFullYear(nextYear);

    let invalidDate = new Date();
    invalidDate.setDate(today.getDate() - 1);
    this.invalidDates = [today, invalidDate];


    this.DataService.getData().subscribe(res => this.sData = res);
    this.fdata = [];

    this.sysdate = Date();
    this.selectedsysdate = this.formatDate(this.sysdate, false);


    //this.ScheduleService.getSchedule().subscribe(res => this.Schedules = res);
    //  console.log(this.ddata);


    this.ScheduleService.getSchedule().subscribe(res => {
      this.Schedules = res;
      this.Schedules = this.Schedules.filter((selectedDate) => selectedDate.day === this.selectedsysdate)
    });

    this.estimateService.getEstimate().subscribe(res => {
      this.Estimate = res;
    });



  }

  navigatedetail(sid: any, mid: any, lid: any) {
    console.log('sid:' + sid);
    console.log('mid:' + mid);
    console.log('lid:' + lid);
    // console.log(this.selectedService.id);
    // console.log(this.selectedModel.id);
    // console.log(this.selectedLocation.id);

    this.router.navigate(['/searchdetails', sid, mid, lid]);

    //   console.log(this.sData);

    // for (var i = 0; i < this.sData.length; i++) {
    //   if (this.sData[i].serviceid == this.selectedService.id && this.sData[i].modelid == this.selectedModel.id && this.sData[i].locationid == this.selectedLocation.id)
    //     //console.log(this.sData[i].fname);
    //     this.fdata.push(this.sData[i]);
    // }
    //  this.router.navigate(['/searchdetails']);
  }

  displaydate() {
    alert('yes');
    this.showSelected = true;

    this.wd1 = this.wd;
    this.ts1 = this.ts;
    this.display = false;


  }

}