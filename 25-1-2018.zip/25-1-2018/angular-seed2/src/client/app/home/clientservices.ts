export class clientServices {
      id: number;
      cid:number;      
      sername: string  
}