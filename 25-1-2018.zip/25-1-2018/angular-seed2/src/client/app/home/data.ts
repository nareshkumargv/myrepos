export class Data {
      id: number; 
      serviceid: number; 
      modelid: number;
      locationid: number;
      fname: string  
}