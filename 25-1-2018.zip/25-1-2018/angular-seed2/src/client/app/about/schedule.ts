export class schedule {
    constructor(public id: number, public day: string, public timeslot: string) { }
}