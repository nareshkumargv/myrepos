import { Component, Input, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-searchdetails',
  templateUrl: 'searchdetails.component.html',
  styleUrls: ['searchdetails.component.css']
})
export class SearchDetailsComponent implements OnInit { 
 
  sid:number;
  mid:number;
  lid:number;
  private sub:any;

  constructor(private route: ActivatedRoute) {}

  ngOnInit() {
    this.sub = this.route.params.subscribe(params => {
       this.sid = +params['sid'];
       this.mid = +params['mid'];
       this.lid = +params['lid'];
       console.log(this.sid);
       console.log(this.mid);
       console.log(this.lid);
    });

}
}