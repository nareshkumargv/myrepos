import { NgModule } from '@angular/core';
//import { CommonModule } from '@angular/common';
import { SearchDetailsComponent } from './searchdetails.component';
import { SearchDetailsRoutingModule } from './searchdetails-routing.module';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [SearchDetailsRoutingModule, SharedModule],
  declarations: [SearchDetailsComponent],
  exports: [SearchDetailsComponent]
})
export class SearchDetailsModule { }