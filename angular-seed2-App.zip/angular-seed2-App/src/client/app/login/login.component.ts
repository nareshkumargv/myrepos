import { Component } from '@angular/core';

import { LocalStorageService } from 'angular-2-local-storage';

@Component({
  moduleId: module.id,
  selector: 'sd-login',
  templateUrl: 'login.component.html'
})
export class LoginComponent  {

     constructor(private localStorageService: LocalStorageService) { }

  ngOnInit(): void {}

}