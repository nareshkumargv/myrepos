import { Injectable } from '@angular/core';

import { Service } from './services';
import { Model } from './models';
import { Location } from './locations';
import { Data } from './data';

@Injectable()
export class FilterService {
    //services: id, name
    getServices() {
        return [
            new Service(1, 'Service 1'),
            new Service(2, 'Service 2'),
            new Service(3, 'Service 3')
        ];
    }
    //Models: id,serviceid,name
    getModels() {
        return [
            new Model(1, 1, 'Model 1'),
            new Model(2, 1, 'Model 1 of 1'),
            new Model(3, 2, 'Model 2'),
            new Model(4, 2, 'Model 2 of 1'),
            new Model(5, 2, 'Model 2 of 2'),
            new Model(6, 3, 'Model 3')
        ];
    }
    // locations: id, serviceid,modelid,name
    getLocations() {
        return [
            new Location(1, 1, 1, 'Loc 1'),
            new Location(2, 1, 1, 'Loc 2'),
            new Location(3, 2, 1, 'Loc 3'),
            new Location(4, 2, 2, 'Loc 4')
        ];
    }

}
