import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';

import { Data } from './data';

@Injectable()
export class DataService {

    constructor(private http: Http) { }

    getData(): Observable<Data[]> {
        return this.http.get('../app/home/data.json')
            .map((res: Response) => res.json());            
    }

    

}