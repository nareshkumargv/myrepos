export class Location {
  constructor(public id: number, public serviceid: number, public modelid: number,  public name: string) { }
}