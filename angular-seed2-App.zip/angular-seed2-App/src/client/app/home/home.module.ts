import { NgModule } from '@angular/core';
import { HomeComponent } from './home.component';
import { HomeRoutingModule } from './home-routing.module';
import { SharedModule } from '../shared/shared.module';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { SearchDetailsModule } from '../searchdetails/searchdetails.module';
//import { SearchDetailsComponent } from '../searchdetails/searchdetails.component';
//import { NameListService } from '../shared/name-list/name-list.service';

import { DataService } from './dataservice';

import {CalendarModule} from 'primeng/primeng';
import {DialogModule} from 'primeng/primeng';
import {RadioButtonModule} from 'primeng/primeng';

import {ScheduleService} from './schedule.service';

@NgModule({
  imports: [HomeRoutingModule, SharedModule, SearchDetailsModule, BrowserAnimationsModule, CalendarModule, DialogModule,RadioButtonModule],
  declarations: [HomeComponent],
  exports: [HomeComponent],
  providers: [DataService, ScheduleService]
})
export class HomeModule { }
