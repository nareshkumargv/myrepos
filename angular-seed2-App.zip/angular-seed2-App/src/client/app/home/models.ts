export class Model {
  constructor(public id: number, public serviceid: number, public name: string) { }
}