import { Component, EventEmitter, Input, OnChanges, OnInit, Output, SimpleChanges } from '@angular/core';
import { Router } from '@angular/router';
import { Http, Response } from '@angular/http';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/filter';

import * as moment from 'moment';
import { unitOfTime } from 'moment';
import * as _ from 'lodash';

import { schedule } from './schedule';
import { ScheduleService } from './schedule.service';

export interface CalendarDate {
  mDate: moment.Moment;
  selected?: boolean;
  today?: boolean;
}

/**
 * This class represents the lazy loaded AboutComponent.
 */
@Component({
  moduleId: module.id,
  selector: 'sd-about',
  templateUrl: 'about.component.html',
  styleUrls: ['about.component.css'],
  providers: [ScheduleService]
})
export class AboutComponent implements OnInit, OnChanges {
items: Array<any> = []

  currentDate = moment();
  dayNames = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];
  weeks: CalendarDate[][] = [];
  sortedDates: CalendarDate[] = [];
  currentWeek: any[] = [];

  @Input() selectedDates: CalendarDate[] = [];
  @Output() onSelectDate = new EventEmitter<CalendarDate>();

  sdate: any;
  dates: any[] = [];
  selectedDate: any;
  weekOfYear: any;
  dayOfWeek: any;
  weekDay: any;
  shortDate: any;
  date: any;
  Schedules: any[];
  clickedDate: any;

  bslots: any[] =[];
  
  fordate: any;
  tdate:any;
  wday:any;

  sweek: any[] = [];
  demo: any[] = [];

  selwk: any;

  todaydate: any;
  currentweek: any;

  days: any[] = [];
  
  constructor(private ScheduleService: ScheduleService) {
    // this.selectedDate = moment().startOf('day').format();
    // console.log(this.selectedDate);
//  this.items = [
//       { name: 'assets/images/thumb1.png' },
//       { name: 'assets/images/thumb2.png' },
//       { name: 'assets/images/thumb3.png' },
//       { name: 'assets/images/thumb4.png' },
//       { name: 'assets/images/thumb5.png' },
//       { name: 'assets/images/thumb6.png' },
//       { name: 'assets/images/thumb1.png' },
//       { name: 'assets/images/thumb2.png' },
//       { name: 'assets/images/thumb3.png' },
//       { name: 'assets/images/thumb4.png' },
//       { name: 'assets/images/thumb5.png' },
//       { name: 'assets/images/thumb6.png' },
//     ]


  }

  _changeDisplayWeek(daysToAdd: any) {
    // console.log(daysToAdd);
    this.selectedDate = moment(this.selectedDate).add(daysToAdd, 'days');
    // console.log(this.selectedDate);
    //this.selectedDate = this.selectedDate.format();
    this.weekOfYear = this.selectedDate.format('WW');
    this.dates = this._expandWeek(this.selectedDate);
    //  console.log(this.dates);
  }

  _expandWeek(startDate: any) {
    //console.log(startDate);
    //this.dayOfWeek = moment(startDate).startOf('isoWeek');
    this.dayOfWeek = moment(startDate).startOf('isoWeek').isoWeekday(0);

    for (var i = 0; i < 7; i++) {
      this.dates.push({
        weekDay: this.dayOfWeek.format('dd'),
        shortDate: this.dayOfWeek.format('DD.MM'),
        date: this.dayOfWeek.format()
      });
      this.dates[i].weekDay = this.dayOfWeek.format('dd'),
        this.dates[i].shortDate = this.dayOfWeek.format('DD.MM'),
        //this.dates[i].date = this.dayOfWeek.format(),
        this.dates[i].date = this.dayOfWeek.format('MM/DD/YYYY'),
        this.dayOfWeek.add(1, 'd');
    }

    return this.dates;
  }

  _selectedWeek(startDate: any) {
    // this.dayOfWeek = moment(startDate).startOf('week').isoWeekday(1);
    this.dayOfWeek = moment(startDate);

    for (var i = 0; i < 7; i++) {
      this.dates.push({
        weekDay: this.dayOfWeek.format('dd'),
        shortDate: this.dayOfWeek.format('DD.MM'),
        date: this.dayOfWeek.format()
      });

      this.dates[i].weekDay = this.dayOfWeek.format('dd'),
        this.dates[i].shortDate = this.dayOfWeek.format('DD.MM'),
        this.dates[i].date = this.dayOfWeek.format()
      this.dayOfWeek.add(1, 'd');
      //console.log(this.dayOfWeek);
    }
    return this.dates;
  }

  prevWeek(): void {
    this._changeDisplayWeek(-7);
  }

  nextWeek(): void {
    this._changeDisplayWeek(7);
  }

  ngOnInit(): void {

    this.generateCalendar();
    this.dates = this._expandWeek(this.selectedDate);

    // this.todaydate = moment().startOf('day').format('DD/MM/YYYY');
    // console.log(this.todaydate);
    // console.log(moment.weekdays(true));

    var startOfWeek = moment(this.date).weekday(0);
    var endOfWeek = moment(this.date).weekday(6);

    //var days = [];
    var day = startOfWeek;
    this.days = [];
    this.sweek = [];
    
    while (day <= endOfWeek) {
      //  days.push(day.toDate());      
      this.days.push(moment(day).format('DD/MM/YYYY'));
      day = day.clone().add(1, 'd');
    }

 this.fordate = moment(this.currentDate).format('DD/MM/YYYY');
    console.log(this.fordate);
    
    this.tdate = moment(this.currentDate).format('D');
    console.log(this.tdate);
    
    this.wday = moment(this.currentDate).format('dddd');
    console.log(this.wday);

 this.ScheduleService.getSchedule().subscribe(res => {
      this.Schedules = res;
      this.Schedules = this.Schedules.filter((selectedDate) => selectedDate.day === this.fordate);
      console.log(this.Schedules);  
    });

  //  console.log(this.days);

    // this.ScheduleService.getSchedule().subscribe(res => {
    //   this.Schedules = res;

    //   this.Schedules.forEach((Date, i) => {
    //     if (this.days.includes(this.Schedules[i].day)) {
    //       this.Schedules[i].day;
    //       this.bslots.push({schdate : this.Schedules[i].day, schtime : this.Schedules[i].timeslot});          
    //      // console.log(this.Schedules[i].day + ' time ' + this.Schedules[i].timeslot);
    //   //   console.log(this.bslots);
    //     }
    //   });


    // });
  }



  ngOnChanges(changes: SimpleChanges): void {
    if (changes.selectedDates &&
      changes.selectedDates.currentValue &&
      changes.selectedDates.currentValue.length > 1) {
      // sort on date changes for better performance when range checking
      this.sortedDates = _.sortBy(changes.selectedDates.currentValue, (m: CalendarDate) => m.mDate.valueOf());
      this.generateCalendar();
    }
  }

  // date checkers
  isToday(date: moment.Moment): boolean {
    return moment().isSame(moment(date), 'day');
  }

  isWeekday(date: moment.Moment): boolean {
    return moment().isSame(moment(date), 'isoWeek');
  }

  isSelected(date: moment.Moment): boolean {
    return _.findIndex(this.selectedDates, (selectedDate: any) => {
      return moment(date).isSame(selectedDate.mDate, 'day');
    }) > -1;
  }

  isSelectedMonth(date: moment.Moment): boolean {
    return moment(date).isSame(this.currentDate, 'month');
  }



  selectDate(cdate: CalendarDate): void {
    let clickedDate: any;
    this.onSelectDate.emit(cdate);

    let seldate = cdate;
    let crdate = this.currentDate;

    var selweeklist: any[];

    this.weeks.filter(weekList => {
      weekList.filter(function (dayList, i) {
        if (dayList.mDate._d.getTime() == seldate.mDate._d.getTime()) {
          selweeklist = weekList;
          console.log(selweeklist);
          clickedDate = weekList[0].mDate;
          console.log(clickedDate);
        }
      });
      this._selectedWeek(clickedDate);
    });

    this.fordate = moment(seldate.mDate).format('DD/MM/YYYY');
    console.log(this.fordate);
    this.tdate = moment(seldate.mDate).format('D');
    console.log(this.tdate);
     this.wday = moment(seldate.mDate).format('dddd');
    console.log(this.wday);

    //moment().format('dddd'); 

    let count = 0;
    this.sweek = [];
    if (count === 0) {
      selweeklist.forEach((date, i) => {
        this.sweek.push(moment(selweeklist[i].mDate).format('DD/MM/YYYY'));
        count++;        
      });
     // console.log(this.sweek);
    }
    this.ScheduleService.getSchedule().subscribe(res => {
      this.Schedules = res;
      this.Schedules = this.Schedules.filter((selectedDate) => selectedDate.day === this.fordate);
      console.log(this.Schedules);

      // this.Schedules.forEach((Date, i) => {
      //   if (this.sweek.includes(this.Schedules[i].day)) {
      //     this.Schedules[i].day;
      //     this.bslots.push({schdate : this.Schedules[i].day, schtime : this.Schedules[i].timeslot}); 
      //     console.log(this.bslots);          
      //   }      
      // });

    });

  }


  // actions from calendar
  prevMonth(): void {
    this.currentDate = moment(this.currentDate).subtract(1, 'months');
    this.generateCalendar();
  }

  nextMonth(): void {
    this.currentDate = moment(this.currentDate).add(1, 'months');
    this.generateCalendar();
  }

  firstMonth(): void {
    this.currentDate = moment(this.currentDate).startOf('year');
    this.generateCalendar();
  }

  lastMonth(): void {
    this.currentDate = moment(this.currentDate).endOf('year');
    this.generateCalendar();
  }

  prevYear(): void {
    this.currentDate = moment(this.currentDate).subtract(1, 'year');
    this.generateCalendar();
  }

  nextYear(): void {
    this.currentDate = moment(this.currentDate).add(1, 'year');
    this.generateCalendar();
  }

nextDay():void {
  this.currentDate = moment(this.currentDate).add(1, 'day');
    this.generateCalendar();
    console.log(this.currentDate);
  
    this.fordate = moment(this.currentDate).format('DD/MM/YYYY');
    console.log(this.fordate);
    
    this.tdate = moment(this.currentDate).format('D');
    console.log(this.tdate);
    
    this.wday = moment(this.currentDate).format('dddd');
    console.log(this.wday);

     this.ScheduleService.getSchedule().subscribe(res => {
      this.Schedules = res;
      this.Schedules = this.Schedules.filter((selectedDate) => selectedDate.day === this.fordate);
      console.log(this.Schedules);
    });
}

prevDay():void {
  this.currentDate = moment(this.currentDate).subtract(1, 'day');
    this.generateCalendar();
    console.log(this.currentDate);
  
    this.fordate = moment(this.currentDate).format('DD/MM/YYYY');
    console.log(this.fordate);
    
    this.tdate = moment(this.currentDate).format('D');
    console.log(this.tdate);
    
    this.wday = moment(this.currentDate).format('dddd');
    console.log(this.wday);

     this.ScheduleService.getSchedule().subscribe(res => {
      this.Schedules = res;
      this.Schedules = this.Schedules.filter((selectedDate) => selectedDate.day === this.fordate);
      console.log(this.Schedules);
    });
}


  // generate the calendar grid
  generateCalendar(): void {
    const dates = this.fillDates(this.currentDate);
    const weeks: CalendarDate[][] = [];
    while (dates.length > 0) {
      weeks.push(dates.splice(0, 7));
    }
    this.weeks = weeks;
    //console.log(this.weeks);
  }

  fillDates(currentMoment: moment.Moment): CalendarDate[] {
    const firstOfMonth = moment(currentMoment).startOf('month').day();
    const firstDayOfGrid = moment(currentMoment).startOf('month').subtract(firstOfMonth, 'days');
    const start = firstDayOfGrid.date();
    return _.range(start, start + 42)
      .map((date: number): CalendarDate => {
        const d = moment(firstDayOfGrid).date(date);
        return {
          today: this.isToday(d),
          selected: this.isSelected(d),
          mDate: d,
        };
      });
  }


}
